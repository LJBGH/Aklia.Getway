﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace IDN.Services.Gateway
{
    public class SwaggerConfigOptions
    {
        public List<SwaggerDocInfo> SwaggerDocInfos { get; set; }
    }

    public class SwaggerDocInfo
    {
        /// <summary> 
        /// 是否启用 
        /// </summary> 
        public bool IsEnabled { get; set; }
        /// <summary> 
        /// 文档标题 
        /// </summary> 
        public string Title { get; set; }
        /// <summary> 
        /// 分组名称 
        /// </summary> 
        public string GroupName { get; set; } = "v1";
        /// <summary> 
        /// 版本 
        /// </summary> 
        public string Version { get; set; } = "v1";
        /// <summary> 
        /// 描述 
        /// </summary> 
        public string Description { get; set; }
        /// <summary> 
        /// 联系信息 
        /// </summary> 
        public ContactInfo Contact { get; set; }
        /// <summary> 
        /// 分组Url前缀 
        /// </summary> 
        public string GroupUrlPrefix { get; set; }
    }
    public class ContactInfo
    {
        /// <summary> 
        /// 联系人名字 
        /// </summary> 
        public string Name { get; set; }
        /// <summary> 
        /// 邮箱 
        /// </summary> 
        public string Email { get; set; }
        /// <summary> 
        /// 联系人网址 
        /// </summary> 
        public string Url { get; set; }
    }
}
